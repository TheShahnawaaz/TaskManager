// src/firebaseConfig.js
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyC3DjT-7uKttm-QP6D_8mCTPulQmgxGD1A",
  authDomain: "todo-dragable.firebaseapp.com",
  projectId: "todo-dragable",
  storageBucket: "todo-dragable.appspot.com",
  messagingSenderId: "164301496521",
  appId: "1:164301496521:web:3f4095da208bb559152d18",
  measurementId: "G-F78G7SF391"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
const db = getFirestore(app);

export { db };
